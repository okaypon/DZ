package main

import (
	"bufio"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

type Player struct {
	HP        int
	MaxHP     int
	Strength  int
	HitPart   int
	BlockPart int
}

type StoryPlayer struct {
	Name      string
	HP        int
	MaxHP     int
	Strength  int
	HitPart   int
	BlockPart int
	Kills     int
	Inventory []Item
}

type Item struct {
	Name  string
	Type  string
	Value int
}

type Room struct {
	Name        string
	Description string
	EnemyChance int
	HasBoss     bool
	IsFinal     bool
}

const (
	Golova = 1
	Puzo   = 2
	Nogi   = 3
)

var storyRooms = []Room{
	{
		Name:        "Палуба",
		Description: "Ночь. Террористы спускаются по верёвкам на палубу корабля. Везде туман...",
		EnemyChance: 0,
	},
	{
		Name:        "Камбуз",
		Description: "Ты заходишь в камбуз. Слышен звон посуды и чьи-то шаги...",
		EnemyChance: 25,
	},
	{
		Name:        "Машинное отделение",
		Description: "Гул машин заглушает звуки. Здесь темно и влажно...",
		EnemyChance: 40,
	},
	{
		Name:        "Арсенал",
		Description: "Оружейная комната. Здесь может быть засада...",
		EnemyChance: 45,
	},
	{
		Name:        "Капитанская каюта",
		Description: "Перед тобой стоит ГЛАВАРЬ ТЕРРОРИСТОВ!",
		EnemyChance: 100,
		HasBoss:     true,
		IsFinal:     true,
	},
}

var weapons = []Item{
	{Name: "Пистолет Макарова", Type: "weapon", Value: 3},
	{Name: "Пистолет-пулемет", Type: "weapon", Value: 4},
	{Name: "Автомат Калашникова", Type: "weapon", Value: 7},
	{Name: "Снайперская винтовка", Type: "weapon", Value: 9},
	{Name: "Ручной пулемет", Type: "weapon", Value: 12},
}

var healItems = []Item{
	{Name: "Бинт", Type: "heal", Value: 30},
	{Name: "Аптечка", Type: "heal", Value: 50},
	{Name: "Медицинский набор", Type: "heal", Value: 60},
	{Name: "Стимулятор", Type: "heal", Value: 80},
	{Name: "Регенератор", Type: "heal", Value: 100},
}

var maxHpItems = []Item{
	{Name: "Витамины", Type: "maxhp", Value: 25},
	{Name: "Стероиды", Type: "maxhp", Value: 35},
	{Name: "Экспериментальный препарат", Type: "maxhp", Value: 45},
	{Name: "Нанороботы", Type: "maxhp", Value: 55},
	{Name: "Генетический усилитель", Type: "maxhp", Value: 65},
}

func bodyPartName(p int) string {
	switch p {
	case Golova:
		return "голову"
	case Nogi:
		return "ноги"
	default:
		return "живот"
	}
}

func partToInt(s string) int {
	s = strings.ToLower(strings.TrimSpace(s))
	switch s {
	case "1", "голова":
		return Golova
	case "3", "ноги":
		return Nogi
	default:
		return Puzo
	}
}

func intToPart(v int) string {
	return bodyPartName(v)
}

func writeLine(conn net.Conn, s string) {
	fmt.Fprintln(conn, s)
}

func chooseBodyPart(reader *bufio.Reader, prompt string) int {
	for {
		fmt.Println(prompt)
		fmt.Println("1 - голова")
		fmt.Println("2 - живот")
		fmt.Println("3 - ноги")
		fmt.Print("Выбор: ")
		s, _ := reader.ReadString('\n')
		s = strings.TrimSpace(s)
		switch s {
		case "1":
			return Golova
		case "2":
			return Puzo
		case "3":
			return Nogi
		default:
			fmt.Println("Неверный выбор, попробуй ещё раз.")
		}
	}
}

func createEnemy(roomIndex int, isBoss bool) *StoryPlayer {
	var baseHp int
	var baseStrength int

	switch roomIndex {
	case 1:
		baseHp = 40
		baseStrength = 6
	case 2:
		baseHp = 70
		baseStrength = 8
	case 3:
		baseHp = 100
		baseStrength = 11
	case 4:
		baseHp = 130
		baseStrength = 14
	default:
		baseHp = 40
		baseStrength = 6
	}

	if isBoss {
		return &StoryPlayer{
			Name:     "ГЛАВАРЬ",
			HP:       160,
			MaxHP:    160,
			Strength: 18,
		}
	}

	names := []string{
		"Боевик", "Наемник", "Снайпер", "Пулеметчик", "Диверсант",
	}
	name := names[rand.Intn(len(names))]

	return &StoryPlayer{
		Name:     name,
		HP:       baseHp,
		MaxHP:    baseHp,
		Strength: baseStrength,
	}
}

func fightPvE(player *StoryPlayer, enemy *StoryPlayer, reader *bufio.Reader) bool {
	fmt.Println("\nБОЙ С " + enemy.Name)
	fmt.Println("Твое здоровье: " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP))
	fmt.Println("Здоровье врага: " + strconv.Itoa(enemy.HP) + "/" + strconv.Itoa(enemy.MaxHP))
	fmt.Println("Сила врага: " + strconv.Itoa(enemy.Strength))

	round := 1
	for player.HP > 0 && enemy.HP > 0 {
		fmt.Println("\nРаунд " + strconv.Itoa(round))

		fmt.Println("Выбери часть тела для атаки:")
		player.HitPart = chooseBodyPart(reader, "Куда бьешь?")

		fmt.Println("Выбери часть тела для блока:")
		player.BlockPart = chooseBodyPart(reader, "Что блокируешь?")

		enemy.HitPart = rand.Intn(3) + 1
		enemy.BlockPart = rand.Intn(3) + 1

		fmt.Println("Ты атакуешь: " + intToPart(player.HitPart) + ", защищаешь: " + intToPart(player.BlockPart))
		fmt.Println(enemy.Name + " атакует: " + intToPart(enemy.HitPart) + ", защищает: " + intToPart(enemy.BlockPart))

		playerDamage := rand.Intn(15) + 10 + player.Strength
		enemyDamage := rand.Intn(15) + 10 + enemy.Strength

		if player.HitPart != enemy.BlockPart {
			enemy.HP -= playerDamage
			if enemy.HP < 0 {
				enemy.HP = 0
			}
			fmt.Println("Ты попадаешь по " + intToPart(player.HitPart) + " на " + strconv.Itoa(playerDamage) + " урона! У врага осталось " + strconv.Itoa(enemy.HP) + " HP.")
		} else {
			fmt.Println(enemy.Name + " блокирует твой удар!")
		}

		if enemy.HP > 0 && enemy.HitPart != player.BlockPart {
			player.HP -= enemyDamage
			if player.HP < 0 {
				player.HP = 0
			}
			fmt.Println(enemy.Name + " попадает по твоему " + intToPart(enemy.HitPart) + " на " + strconv.Itoa(enemyDamage) + " урона! У тебя осталось " + strconv.Itoa(player.HP) + " HP.")
		} else if enemy.HP > 0 {
			fmt.Println("Ты блокируешь удар " + enemy.Name + "!")
		}

		fmt.Println("Статус: Ты " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP) + " HP, " + enemy.Name + " " + strconv.Itoa(enemy.HP) + "/" + strconv.Itoa(enemy.MaxHP) + " HP")
		round++

		if player.HP <= 0 {
			fmt.Println("\nТы погиб в бою...")
			return false
		}

		if enemy.HP <= 0 {
			fmt.Println("\nТы победил " + enemy.Name + "!")
			player.Kills++

			fmt.Println("Всего убито врагов: " + strconv.Itoa(player.Kills))

			if rand.Intn(100) < 70 {
				findRandomItem(player)
			}

			return true
		}
	}
	return false
}

func findRandomItem(player *StoryPlayer) {
	fmt.Println("\nТы нашел предмет!")

	chance := rand.Intn(100)

	if chance < 33 {
		item := weapons[rand.Intn(len(weapons))]
		player.Inventory = append(player.Inventory, item)
		fmt.Println("+" + item.Name + " (сила +" + strconv.Itoa(item.Value) + ") добавлен в инвентарь!")
	} else if chance < 66 {
		item := healItems[rand.Intn(len(healItems))]
		player.Inventory = append(player.Inventory, item)
		fmt.Println("+" + item.Name + " (восстанавливает " + strconv.Itoa(item.Value) + " HP) добавлен в инвентарь!")
	} else {
		item := maxHpItems[rand.Intn(len(maxHpItems))]
		player.Inventory = append(player.Inventory, item)
		fmt.Println("+" + item.Name + " (увеличивает макс. здоровье на " + strconv.Itoa(item.Value) + ") добавлен в инвентарь!")
	}
}

func useItem(player *StoryPlayer, index int) {
	if index < 0 || index >= len(player.Inventory) {
		fmt.Println("Неверный номер предмета!")
		return
	}

	item := player.Inventory[index]

	switch item.Type {
	case "heal":
		player.HP += item.Value
		if player.HP > player.MaxHP {
			player.HP = player.MaxHP
		}
		fmt.Println("Ты использовал " + item.Name + "! Восстановлено " + strconv.Itoa(item.Value) + " HP. Теперь у тебя " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP) + " HP.")
	case "weapon":
		player.Strength += item.Value
		fmt.Println("Ты использовал " + item.Name + "! Сила увеличилась на " + strconv.Itoa(item.Value) + ". Теперь сила " + strconv.Itoa(player.Strength) + ".")
	case "maxhp":
		player.MaxHP += item.Value
		player.HP += item.Value
		fmt.Println("Ты использовал " + item.Name + "! Максимальное здоровье увеличилось на " + strconv.Itoa(item.Value) + ". Теперь у тебя " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP) + " HP.")
	}

	player.Inventory = append(player.Inventory[:index], player.Inventory[index+1:]...)
}

func showInventory(player *StoryPlayer, reader *bufio.Reader) {
	for {
		fmt.Println("\nИНВЕНТАРЬ " + player.Name + ":")
		if len(player.Inventory) == 0 {
			fmt.Println("Инвентарь пуст.")
			fmt.Println("\nНажми Enter, чтобы вернуться...")
			reader.ReadString('\n')
			return
		}

		fmt.Println("\nОРУЖИЕ:")
		weaponCount := 0
		for i, item := range player.Inventory {
			if item.Type == "weapon" {
				fmt.Println("  " + strconv.Itoa(i+1) + " - " + item.Name + " (сила +" + strconv.Itoa(item.Value) + ")")
				weaponCount++
			}
		}
		if weaponCount == 0 {
			fmt.Println("  Нет оружия")
		}

		fmt.Println("\nЛЕЧЕНИЕ:")
		healCount := 0
		for i, item := range player.Inventory {
			if item.Type == "heal" {
				fmt.Println("  " + strconv.Itoa(i+1) + " - " + item.Name + " (+" + strconv.Itoa(item.Value) + " HP)")
				healCount++
			}
		}
		if healCount == 0 {
			fmt.Println("  Нет лечебных предметов")
		}

		fmt.Println("\nУВЕЛИЧЕНИЕ ЗДОРОВЬЯ:")
		maxHpCount := 0
		for i, item := range player.Inventory {
			if item.Type == "maxhp" {
				fmt.Println("  " + strconv.Itoa(i+1) + " - " + item.Name + " (+" + strconv.Itoa(item.Value) + " макс. HP)")
				maxHpCount++
			}
		}
		if maxHpCount == 0 {
			fmt.Println("  Нет предметов для увеличения здоровья")
		}

		fmt.Println("\n0 - Назад")
		fmt.Print("Выбери предмет для использования (или 0 для выхода): ")

		choice, _ := reader.ReadString('\n')
		choice = strings.TrimSpace(choice)
		if choice == "0" {
			return
		}

		itemIndex, err := strconv.Atoi(choice)
		if err != nil || itemIndex < 1 || itemIndex > len(player.Inventory) {
			fmt.Println("Неверный выбор!")
			continue
		}

		useItem(player, itemIndex-1)
	}
}

func storyMode() {
	reader := bufio.NewReader(os.Stdin)
	rand.Seed(time.Now().UnixNano())

	fmt.Print("Введите имя спецназовца: ")
	name, _ := reader.ReadString('\n')
	name = strings.TrimSpace(name)
	if name == "" {
		name = "Спецназовец"
	}

	player := &StoryPlayer{
		Name:      name,
		HP:        120,
		MaxHP:     120,
		Strength:  7,
		Kills:     0,
		Inventory: []Item{},
	}

	fmt.Println("\nСЮЖЕТНЫЙ РЕЖИМ: ЗАХВАТ КОРАБЛЯ")
	fmt.Println("Ночь. Террористы спускаются по верёвкам на военный корабль.")
	fmt.Println("Ты - спецназовец, который должен пройти через все отсеки корабля, найти и уничтожить главаря террористов.")
	fmt.Println("\nНа корабле 5 отсеков. Чем дальше - тем опаснее.")
	fmt.Println("\nТвои начальные характеристики:")
	fmt.Println("   Здоровье: " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP))
	fmt.Println("   Сила: " + strconv.Itoa(player.Strength))
	fmt.Println("\nНажми Enter, чтобы начать...")
	reader.ReadString('\n')

	roomIndex := 0
	for roomIndex < len(storyRooms) {
		currentRoom := storyRooms[roomIndex]

		fmt.Println("\n" + currentRoom.Name)
		fmt.Println(currentRoom.Description)

		if currentRoom.IsFinal {
			fmt.Println("\nЭто последний отсек! Здесь точно будет бой!")

			for {
				fmt.Println("\nДЕЙСТВИЯ:")
				fmt.Println("1 - Начать бой с главарем")
				fmt.Println("2 - Проверить экипировку")
				fmt.Println("3 - Инвентарь")
				fmt.Println("0 - Сдаться и покинуть корабль")
				fmt.Print("Выбор: ")

				choice, _ := reader.ReadString('\n')
				choice = strings.TrimSpace(choice)

				switch choice {
				case "1":
					fmt.Println("\nТы входишь в каюту...")

					boss := createEnemy(roomIndex, true)
					fmt.Println("\nПЕРЕД ТОБОЙ " + boss.Name + "!")
					fmt.Println("Его здоровье: " + strconv.Itoa(boss.HP) + "/" + strconv.Itoa(boss.MaxHP))
					fmt.Println("Его сила: " + strconv.Itoa(boss.Strength))
					fmt.Println("Это финальный бой!")

					if !fightPvE(player, boss, reader) {
						fmt.Println("\nТы погиб в финальной битве... Корабль захвачен террористами.")
					} else {
						fmt.Println("\nТЫ ПОБЕДИЛ ГЛАВАРЯ! Террористы отступают!")
						fmt.Println("\nИТОГОВАЯ СТАТИСТИКА:")
						fmt.Println("   Убито террористов: " + strconv.Itoa(player.Kills))
						fmt.Println("   Сила: " + strconv.Itoa(player.Strength))
						fmt.Println("   Здоровье: " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP))
						fmt.Println("   Предметов в инвентаре: " + strconv.Itoa(len(player.Inventory)))
						fmt.Println("\nКорабль спасен! Миссия выполнена!")
					}

					fmt.Println("\nНажми Enter, чтобы вернуться в меню...")
					reader.ReadString('\n')
					return

				case "2":
					fmt.Println("\nЭКИПИРОВКА " + player.Name + ":")
					fmt.Println("   Здоровье: " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP))
					fmt.Println("   Сила: " + strconv.Itoa(player.Strength))
					fmt.Println("   Убито террористов: " + strconv.Itoa(player.Kills))
					fmt.Println("   Предметов в инвентаре: " + strconv.Itoa(len(player.Inventory)))
					fmt.Println("\nНажми Enter, чтобы продолжить...")
					reader.ReadString('\n')

				case "3":
					showInventory(player, reader)

				case "0":
					fmt.Println("\nТы покидаешь корабль... Миссия провалена.")
					fmt.Println("\nНажми Enter, чтобы вернуться в меню...")
					reader.ReadString('\n')
					return

				default:
					fmt.Println("Неверный выбор!")
				}
			}
		}

		if roomIndex > 0 {
			var expectedHp int
			var expectedStrength int

			switch roomIndex {
			case 1:
				expectedHp = 40
				expectedStrength = 6
			case 2:
				expectedHp = 70
				expectedStrength = 8
			case 3:
				expectedHp = 100
				expectedStrength = 11
			case 4:
				expectedHp = 130
				expectedStrength = 14
			}

			fmt.Println("\nШанс встретить врага: " + strconv.Itoa(currentRoom.EnemyChance) + "%")
			fmt.Println("Характеристики врага: здоровье " + strconv.Itoa(expectedHp) + ", сила " + strconv.Itoa(expectedStrength))
		} else {
			fmt.Println("\nНа палубе никого нет. Можно осмотреться.")
		}

		fmt.Println("\nДЕЙСТВИЯ:")
		fmt.Println("1 - Обыскать отсек")
		fmt.Println("2 - Перейти в другой отсек")
		fmt.Println("3 - Проверить экипировку")
		fmt.Println("4 - Инвентарь")
		fmt.Println("0 - Сдаться и покинуть корабль")
		fmt.Print("Выбор: ")

		choice, _ := reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		switch choice {
		case "1":
			fmt.Println("\nТы обыскиваешь отсек...")
			time.Sleep(1 * time.Second)

			if roomIndex == 0 {
				fmt.Println("На палубе пусто. Можно идти дальше.")
				if rand.Intn(100) < 60 {
					findRandomItem(player)
				}
				roomIndex++
			} else {
				chance := rand.Intn(100)
				if chance < currentRoom.EnemyChance {
					fmt.Println("Ты наткнулся на врага!")

					enemy := createEnemy(roomIndex, false)
					fmt.Println("Его здоровье: " + strconv.Itoa(enemy.HP) + "/" + strconv.Itoa(enemy.MaxHP))
					fmt.Println("Его сила: " + strconv.Itoa(enemy.Strength))

					if !fightPvE(player, enemy, reader) {
						fmt.Println("\nТы погиб в бою...")
						fmt.Println("\nНажми Enter, чтобы вернуться в меню...")
						reader.ReadString('\n')
						return
					}

					if player.HP > 0 {
						fmt.Println("\nМожно двигаться дальше...")
						roomIndex++
					}
				} else {
					fmt.Println("В отсеке никого нет. Можно идти дальше.")
					if rand.Intn(100) < 60 {
						findRandomItem(player)
					}
					roomIndex++
				}
			}

		case "2":
			if roomIndex < len(storyRooms)-1 {
				fmt.Println("\nТы переходишь в другой отсек...")
				roomIndex++
			} else {
				fmt.Println("Дальше только финальный отсек!")
			}

		case "3":
			fmt.Println("\nЭКИПИРОВКА " + player.Name + ":")
			fmt.Println("   Здоровье: " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP))
			fmt.Println("   Сила: " + strconv.Itoa(player.Strength))
			fmt.Println("   Убито террористов: " + strconv.Itoa(player.Kills))
			fmt.Println("   Предметов в инвентаре: " + strconv.Itoa(len(player.Inventory)))
			fmt.Println("   Текущий отсек: " + storyRooms[roomIndex].Name)
			fmt.Println("\nНажми Enter, чтобы продолжить...")
			reader.ReadString('\n')

		case "4":
			showInventory(player, reader)

		case "0":
			fmt.Println("\nТы покидаешь корабль... Миссия провалена.")
			fmt.Println("\nНажми Enter, чтобы вернуться в меню...")
			reader.ReadString('\n')
			return

		default:
			fmt.Println("Неверный выбор!")
		}

		if player.HP <= 0 {
			fmt.Println("\nТы погиб... Корабль захвачен террористами.")
			fmt.Println("\nНажми Enter, чтобы вернуться в меню...")
			reader.ReadString('\n')
			break
		}
	}
}

func fightLocal() {
	rand.Seed(time.Now().UnixNano())
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Введите своё имя: ")
	name, _ := reader.ReadString('\n')
	name = strings.TrimSpace(name)

	fmt.Println("\nОДИНОЧНЫЙ БОЙ ПРОТИВ БОТА")
	fmt.Println("Против тебя выходит террорист. Бой начинается.")

	player := &Player{HP: 100, MaxHP: 100, Strength: 5}
	enemy := &Player{HP: 100, MaxHP: 100, Strength: 5}

	round := 1
	for player.HP > 0 && enemy.HP > 0 {
		fmt.Println("\nРаунд " + strconv.Itoa(round))

		fmt.Println("Выбери часть тела для атаки (1-голова,2-живот,3-ноги):")
		fmt.Print("> ")
		aStr, _ := reader.ReadString('\n')
		player.HitPart = partToInt(aStr)

		fmt.Println("Выбери часть тела для блока (1-голова,2-живот,3-ноги):")
		fmt.Print("> ")
		bStr, _ := reader.ReadString('\n')
		player.BlockPart = partToInt(bStr)

		enemy.HitPart = rand.Intn(3) + 1
		enemy.BlockPart = rand.Intn(3) + 1

		fmt.Println("Ты атакуешь: " + intToPart(player.HitPart) + ", защищаешь: " + intToPart(player.BlockPart))
		fmt.Println("Террорист атакует: " + intToPart(enemy.HitPart) + ", защищает: " + intToPart(enemy.BlockPart))

		playerDamage := rand.Intn(15) + 10 + player.Strength
		enemyDamage := rand.Intn(15) + 10 + enemy.Strength

		if player.HitPart != enemy.BlockPart {
			enemy.HP -= playerDamage
			if enemy.HP < 0 {
				enemy.HP = 0
			}
			fmt.Println("Ты наносишь " + strconv.Itoa(playerDamage) + " урона. У врага " + strconv.Itoa(enemy.HP) + " HP.")
		} else {
			fmt.Println("Террорист блокирует твой удар.")
		}

		if enemy.HP > 0 && enemy.HitPart != player.BlockPart {
			player.HP -= enemyDamage
			if player.HP < 0 {
				player.HP = 0
			}
			fmt.Println("Ты получаешь " + strconv.Itoa(enemyDamage) + " урона. У тебя " + strconv.Itoa(player.HP) + " HP.")
		} else if enemy.HP > 0 {
			fmt.Println("Ты блокируешь удар врага.")
		}

		fmt.Println("Статус: Ты " + strconv.Itoa(player.HP) + "/" + strconv.Itoa(player.MaxHP) + " HP, Террорист " + strconv.Itoa(enemy.HP) + "/" + strconv.Itoa(enemy.MaxHP) + " HP.")
		round++
	}

	if player.HP > 0 {
		fmt.Println("\nТы победил! Террорист повержен.")
	} else {
		fmt.Println("\nТы проиграл...")
	}

	fmt.Println("\nНажмите Enter, чтобы вернуться в меню...")
	bufio.NewReader(os.Stdin).ReadString('\n')
}

func fightNetServer() {
	stdin := bufio.NewReader(os.Stdin)

	fmt.Println("\nМУЛЬТИПЛЕЕР - СЕРВЕР")
	fmt.Println("Сервер будет слушать на localhost:<порт>")
	fmt.Println("Введите порт, например: 3333")
	fmt.Print("Порт: ")
	line, _ := stdin.ReadString('\n')
	line = strings.TrimSpace(line)
	if line == "" {
		line = "8080"
	}
	addr := "localhost:" + line

	ln, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	fmt.Println("Сервер запущен на " + addr + ", ожидаю подключения клиента...")
	fmt.Println("(Для отмены нажмите Ctrl+C)")

	ln.(*net.TCPListener).SetDeadline(time.Now().Add(2 * time.Minute))

	conn, err := ln.Accept()
	if err != nil {
		fmt.Println("Таймаут ожидания подключения или ошибка: " + err.Error())
		fmt.Println("Возврат в меню...")
		time.Sleep(2 * time.Second)
		return
	}
	defer conn.Close()
	fmt.Println("Клиент подключился!")

	rand.Seed(time.Now().UnixNano())

	fmt.Print("Введите своё имя (сервер): ")
	serverPlayerName, _ := stdin.ReadString('\n')
	serverPlayerName = strings.TrimSpace(serverPlayerName)

	writeLine(conn, "[NAME_SERVER] "+serverPlayerName)

	clientPlayerName := "Террорист"
	clientReader := bufio.NewReader(conn)
	for {
		nameLine, err := clientReader.ReadString('\n')
		if err != nil {
			fmt.Println("Ошибка при чтении имени клиента: " + err.Error())
			return
		}
		nameLine = strings.TrimSpace(nameLine)
		if strings.HasPrefix(nameLine, "[NAME_CLIENT] ") {
			clientPlayerName = strings.TrimPrefix(nameLine, "[NAME_CLIENT] ")
			break
		}
	}

	fmt.Println("Твоё имя: " + serverPlayerName)
	fmt.Println("Имя второго игрока: " + clientPlayerName)

	serverPlayer := &Player{HP: 100, MaxHP: 100, Strength: 5}
	clientPlayer := &Player{HP: 100, MaxHP: 100, Strength: 5}

	intro := []string{
		"МУЛЬТИПЛЕЕР: PvP БОЙ",
		"Ты — " + clientPlayerName + " (клиент), сервер играет за " + serverPlayerName + ".",
		"Для начала боя введи /ready",
		"Чат работает постоянно - просто пиши сообщения",
	}
	for _, line := range intro {
		writeLine(conn, line)
	}

	fmt.Println("\nМУЛЬТИПЛЕЕР: PvP БОЙ")
	fmt.Println("Ты — " + serverPlayerName + " (сервер), клиент играет за " + clientPlayerName)
	fmt.Println("Для начала боя введи /ready")
	fmt.Println("Чат работает постоянно - просто пиши сообщения")

	gameStarted := false
	roundActive := false
	serverReady := false
	clientReady := false
	waitingForNextRound := false

	gameOver := make(chan bool)

	go func() {
		for {
			message, err := clientReader.ReadString('\n')
			if err != nil {
				fmt.Println("Клиент отключился.")
				gameOver <- true
				return
			}
			message = strings.TrimSpace(message)
			if message != "" {
				if strings.HasPrefix(message, serverPlayerName+":") {
					continue
				}

				if message == "/ready" {
					if !gameStarted {
						clientReady = true
						writeLine(conn, "Ты подтвердил готовность к бою. Ожидаем подтверждение сервера...")
						fmt.Println(clientPlayerName + " готов к бою!")

						if serverReady && clientReady {
							gameStarted = true
							roundActive = true
							writeLine(conn, "БОЙ НАЧИНАЕТСЯ! Выбери атаку и блок:")
							fmt.Println("БОЙ НАЧИНАЕТСЯ!")
							fmt.Println("Выбери атаку и блок:")
							hitPart := chooseBodyPart(stdin, "Куда бьешь?")
							blockPart := chooseBodyPart(stdin, "Что блокируешь?")

							serverPlayer.HitPart = hitPart
							serverPlayer.BlockPart = blockPart
							serverReady = true

							fmt.Println("Твой выбор отправлен. Ожидаем выбор клиента...")
							writeLine(conn, "/hit "+strconv.Itoa(hitPart)+" "+strconv.Itoa(blockPart))
						}
					} else if waitingForNextRound {
						clientReady = true
						writeLine(conn, "Ты готов к следующему раунду. Ожидаем сервер...")
						fmt.Println(clientPlayerName + " готов к следующему раунду!")

						if serverReady && clientReady {
							roundActive = true
							waitingForNextRound = false
							serverReady = false
							clientReady = false
							fmt.Println("\nСЛЕДУЮЩИЙ РАУНД")
							fmt.Println("Выбери атаку и блок:")
							hitPart := chooseBodyPart(stdin, "Куда бьешь?")
							blockPart := chooseBodyPart(stdin, "Что блокируешь?")

							serverPlayer.HitPart = hitPart
							serverPlayer.BlockPart = blockPart
							serverReady = true

							fmt.Println("Твой выбор отправлен. Ожидаем выбор клиента...")
							writeLine(conn, "/hit "+strconv.Itoa(hitPart)+" "+strconv.Itoa(blockPart))
						}
					}
				} else if gameStarted && roundActive {
					if strings.HasPrefix(message, "/hit") {
						parts := strings.Split(message, " ")
						if len(parts) == 3 {
							hitPart, _ := strconv.Atoi(parts[1])
							blockPart, _ := strconv.Atoi(parts[2])
							clientPlayer.HitPart = hitPart
							clientPlayer.BlockPart = blockPart
							clientReady = true
							fmt.Println(clientPlayerName + " сделал свой выбор")

							if serverReady && clientReady {
								isGameOver := calculateRound(serverPlayer, clientPlayer, conn)
								serverReady = false
								clientReady = false
								roundActive = false

								if isGameOver {
									gameOver <- true
									return
								}

								if serverPlayer.HP > 0 && clientPlayer.HP > 0 {
									waitingForNextRound = true
									fmt.Println("\nРаунд завершен. Введи /ready для следующего раунда")
									writeLine(conn, "Раунд завершен. Введи /ready для следующего раунда")
								}
							}
						}
					}
				} else {
					fmt.Println(message)
				}
			}
		}
	}()

	for {
		select {
		case <-gameOver:
			fmt.Println("\nИгра завершена. Возврат в меню...")
			time.Sleep(2 * time.Second)
			return
		default:
			if gameStarted && roundActive {
				time.Sleep(100 * time.Millisecond)
				continue
			}

			fmt.Print("\n> ")
			text, _ := stdin.ReadString('\n')
			text = strings.TrimSpace(text)
			if text == "" {
				continue
			}

			if text == "/ready" {
				if !gameStarted {
					serverReady = true
					fmt.Println("Ты подтвердил готовность к бою. Ожидаем подтверждение клиента...")
					writeLine(conn, serverPlayerName+" готов к бою!")

					if serverReady && clientReady {
						gameStarted = true
						roundActive = true
						writeLine(conn, "БОЙ НАЧИНАЕТСЯ! Выбери атаку и блок:")
						fmt.Println("БОЙ НАЧИНАЕТСЯ!")
						fmt.Println("Выбери атаку и блок:")
						hitPart := chooseBodyPart(stdin, "Куда бьешь?")
						blockPart := chooseBodyPart(stdin, "Что блокируешь?")

						serverPlayer.HitPart = hitPart
						serverPlayer.BlockPart = blockPart
						serverReady = true

						fmt.Println("Твой выбор отправлен. Ожидаем выбор клиента...")
						writeLine(conn, "/hit "+strconv.Itoa(hitPart)+" "+strconv.Itoa(blockPart))
					}
				} else if waitingForNextRound {
					serverReady = true
					fmt.Println("Ты готов к следующему раунду. Ожидаем клиента...")
					writeLine(conn, serverPlayerName+" готов к следующему раунду!")

					if serverReady && clientReady {
						roundActive = true
						waitingForNextRound = false
						serverReady = false
						clientReady = false
						fmt.Println("\nСЛЕДУЮЩИЙ РАУНД")
						fmt.Println("Выбери атаку и блок:")
						hitPart := chooseBodyPart(stdin, "Куда бьешь?")
						blockPart := chooseBodyPart(stdin, "Что блокируешь?")

						serverPlayer.HitPart = hitPart
						serverPlayer.BlockPart = blockPart
						serverReady = true

						fmt.Println("Твой выбор отправлен. Ожидаем выбор клиента...")
						writeLine(conn, "/hit "+strconv.Itoa(hitPart)+" "+strconv.Itoa(blockPart))
					}
				}
			} else {
				if gameStarted {
					writeLine(conn, serverPlayerName+": "+text)
				} else {
					writeLine(conn, serverPlayerName+": "+text)
				}
			}
		}
	}
}

func calculateRound(serverPlayer, clientPlayer *Player, conn net.Conn) bool {
	fmt.Println("\nРЕЗУЛЬТАТЫ РАУНДА")
	writeLine(conn, "РЕЗУЛЬТАТЫ РАУНДА")

	serverPlayerDamage := rand.Intn(15) + 10 + serverPlayer.Strength
	clientPlayerDamage := rand.Intn(15) + 10 + clientPlayer.Strength

	if serverPlayer.HitPart != clientPlayer.BlockPart {
		clientPlayer.HP -= serverPlayerDamage
		if clientPlayer.HP < 0 {
			clientPlayer.HP = 0
		}
		fightMessage := "Сервер попадает по " + intToPart(serverPlayer.HitPart) + " на " + strconv.Itoa(serverPlayerDamage) + " урона. У клиента осталось " + strconv.Itoa(clientPlayer.HP) + " HP."
		writeLine(conn, fightMessage)
		fmt.Println(fightMessage)
	} else {
		fightMessage := "Клиент блокирует удар сервера"
		writeLine(conn, fightMessage)
		fmt.Println(fightMessage)
	}

	if clientPlayer.HP > 0 && clientPlayer.HitPart != serverPlayer.BlockPart {
		serverPlayer.HP -= clientPlayerDamage
		if serverPlayer.HP < 0 {
			serverPlayer.HP = 0
		}
		fightMessage := "Клиент попадает по " + intToPart(clientPlayer.HitPart) + " на " + strconv.Itoa(clientPlayerDamage) + " урона. У сервера осталось " + strconv.Itoa(serverPlayer.HP) + " HP."
		writeLine(conn, fightMessage)
		fmt.Println(fightMessage)
	} else if clientPlayer.HP > 0 {
		fightMessage := "Сервер блокирует удар клиента"
		writeLine(conn, fightMessage)
		fmt.Println(fightMessage)
	}

	statusMessage := "Статус: Сервер: " + strconv.Itoa(serverPlayer.HP) + " HP, Клиент: " + strconv.Itoa(clientPlayer.HP) + " HP"
	writeLine(conn, statusMessage)
	fmt.Println(statusMessage)

	if serverPlayer.HP <= 0 {
		finalMessage := "Победил клиент!"
		writeLine(conn, finalMessage)
		fmt.Println(finalMessage)
		return true
	} else if clientPlayer.HP <= 0 {
		finalMessage := "Победил сервер!"
		writeLine(conn, finalMessage)
		fmt.Println(finalMessage)
		return true
	}
	return false
}

func fightNetClient() {
	stdinReader := bufio.NewReader(os.Stdin)

	fmt.Println("\nМУЛЬТИПЛЕЕР - КЛИЕНТ")
	fmt.Println("Клиент подключается к localhost:<порт>")
	fmt.Println("Введите порт сервера, например: 3333")
	fmt.Print("Порт: ")
	line, _ := stdinReader.ReadString('\n')
	line = strings.TrimSpace(line)
	if line == "" {
		line = "8080"
	}
	addr := "localhost:" + line

	conn, err := net.Dial("tcp", addr)
	if err != nil {
		fmt.Println("Ошибка подключения к серверу: " + err.Error())
		fmt.Println("Нажмите Enter, чтобы вернуться в меню...")
		bufio.NewReader(os.Stdin).ReadString('\n')
		return
	}
	defer conn.Close()
	fmt.Println("Подключился к серверу " + addr)

	serverReader := bufio.NewReader(conn)

	serverPlayerName := "Спецназ"
	for {
		line, err := serverReader.ReadString('\n')
		if err != nil {
			fmt.Println("Соединение закрыто сервером.")
			fmt.Println("Нажмите Enter, чтобы вернуться в меню...")
			bufio.NewReader(os.Stdin).ReadString('\n')
			return
		}
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "[NAME_SERVER] ") {
			serverPlayerName = strings.TrimPrefix(line, "[NAME_SERVER] ")
			break
		}
	}

	fmt.Print("Введите своё имя (клиент): ")
	clientPlayerName, _ := stdinReader.ReadString('\n')
	clientPlayerName = strings.TrimSpace(clientPlayerName)

	fmt.Fprintln(conn, "[NAME_CLIENT] "+clientPlayerName)

	fmt.Println("Имя сервера: " + serverPlayerName)
	fmt.Println("Твоё имя: " + clientPlayerName)

	for i := 0; i < 4; i++ {
		line, _ := serverReader.ReadString('\n')
		fmt.Print(strings.TrimSpace(line) + "\n")
	}

	waitingForChoice := false
	waitingForNextRound := false
	gameOver := make(chan bool)

	go func() {
		for {
			message, err := serverReader.ReadString('\n')
			if err != nil {
				fmt.Println("\nСоединение с сервером закрыто.")
				gameOver <- true
				return
			}
			message = strings.TrimSpace(message)
			if message != "" {
				if strings.HasPrefix(message, "/hit ") {
					waitingForChoice = true
				} else if strings.Contains(message, "Раунд завершен") {
					waitingForNextRound = true
					fmt.Println(message)
				} else if !strings.HasPrefix(message, "/") {
					fmt.Println(message)
					if strings.Contains(message, "Победил") {
						gameOver <- true
						return
					}
				}
			}
		}
	}()

	readySent := false
	for {
		select {
		case <-gameOver:
			fmt.Println("\nИгра завершена. Нажмите Enter, чтобы вернуться в меню...")
			bufio.NewReader(os.Stdin).ReadString('\n')
			return
		default:
			if waitingForChoice {
				waitingForChoice = false
				fmt.Println("\nТВОЙ ХОД!")
				fmt.Println("Выбери атаку и блок:")
				hitPart := chooseBodyPart(stdinReader, "Куда бьешь?")
				blockPart := chooseBodyPart(stdinReader, "Что блокируешь?")

				cmd := "/hit " + strconv.Itoa(hitPart) + " " + strconv.Itoa(blockPart)
				fmt.Fprintln(conn, cmd)
				fmt.Println("Твой выбор отправлен. Ожидаем результат...")
				continue
			}

			if waitingForNextRound {
				fmt.Println("\nОжидание следующего раунда. Введи /ready чтобы продолжить.")
				waitingForNextRound = false
			}

			fmt.Print("\n> ")
			text, _ := stdinReader.ReadString('\n')
			text = strings.TrimSpace(text)
			if text == "" {
				continue
			}

			if text == "/ready" {
				fmt.Fprintln(conn, "/ready")
				if !readySent {
					fmt.Println("Ты подтвердил готовность к бою. Ожидаем подтверждение сервера...")
					readySent = true
				} else {
					fmt.Println("Ты готов к следующему раунду. Ожидаем сервер...")
				}
			} else {
				fmt.Fprintln(conn, clientPlayerName+": "+text)
			}
		}
	}
}
func multiplayerMenu() {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Println("\nМУЛЬТИПЛЕЕР (PvP)")
		fmt.Println("1 - Запустить сервер")
		fmt.Println("2 - Подключиться как клиент")
		fmt.Println("0 - Назад в главное меню")
		fmt.Print("Выбор: ")

		choiceStr, _ := reader.ReadString('\n')
		choiceStr = strings.TrimSpace(choiceStr)
		choice, _ := strconv.Atoi(choiceStr)

		switch choice {
		case 1:
			fightNetServer()
		case 2:
			fightNetClient()
		case 0:
			return
		default:
			fmt.Println("Неверный выбор.")
		}
	}
}

func main() {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Println("\nГЛАВНОЕ МЕНЮ")
		fmt.Println("1 - Мультиплеер (PvP 1x1)")
		fmt.Println("2 - Одиночный бой (против бота)")
		fmt.Println("3 - СЮЖЕТНЫЙ РЕЖИМ: Захват корабля")
		fmt.Println("0 - Выход")
		fmt.Print("Выбор: ")

		choiceStr, _ := reader.ReadString('\n')
		choiceStr = strings.TrimSpace(choiceStr)
		choice, _ := strconv.Atoi(choiceStr)

		switch choice {
		case 1:
			multiplayerMenu()
		case 2:
			fightLocal()
		case 3:
			storyMode()
		case 0:
			fmt.Println("Выход. Спасибо за игру!")
			return
		default:
			fmt.Println("Неверный выбор.")
		}
	}
}
