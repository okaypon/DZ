package main

import (
 "errors"
 "fmt"
)

type Product struct {
 Id       int
 Name     string
 Price    float64
 Quantity int
}

type Inventory struct {
 products map[int]Product
}

func (i *Inventory) AddProduct(product Product) {
 if i.products == nil {
  i.products = make(map[int]Product)
 }
 i.products[product.Id] = product
}

func (i *Inventory) WriteOff(productID int, quantity int) error {
 product, ok := i.products[productID]
 if !ok {
  return errors.New("товар не найден")
 }
 if product.Quantity < quantity {
  return errors.New("этого товара нет в таком количестве")
 }
 product.Quantity -= quantity
 i.products[productID] = product
 return nil
}

func (i *Inventory) RemoveProduct(productID int) error {
 if _, ok := i.products[productID]; !ok {
  return errors.New("товар не найден")
 }
 delete(i.products, productID)
 return nil
}

func (i *Inventory) GetTotalValue() float64 {
 total := 0.0
 for _, product := range i.products {
  total += product.Price * float64(product.Quantity)
 }
 return total
}

func main() {
 inventory := &Inventory{}

 inventory.AddProduct(Product{1, "калькулятор", 230, 15})
 inventory.AddProduct(Product{2, "мышь компьютерная", 12430, 5})

 fmt.Printf("общая стоимость: %.2f\n", inventory.GetTotalValue())

 err := inventory.WriteOff(1, 1)
 if err != nil {
  fmt.Println("ошибка: ", err)
 } else {
  fmt.Println("списание")
 }

 fmt.Printf("общая стоимость после списания: %.2f\n", inventory.GetTotalValue())

 inventory.RemoveProduct(1)
 fmt.Printf("общая стоимость после удаления: %.2f\n", inventory.GetTotalValue())
}