package main

import (
	"fmt"
	"time"
)

type Cache struct {
	data map[string]cache
}

type cache struct {
	value   interface{}
	expires time.Time
}

func (c *Cache) Set(key string, value interface{}, ttl time.Duration) {
	if c.data == nil {
		c.data = make(map[string]cache)
	}
	c.data[key] = cache{value, time.Now().Add(ttl)}
}

func (c *Cache) Get(key string) (interface{}, bool) {
	item, found := c.data[key]
	if !found || time.Now().After(item.expires) {
		return nil, false
	}
	return item.value, true
}

func (c *Cache) Delete(key string) {
	delete(c.data, key)
}

func main() {
	var cache Cache

	cache.Set("Имя", "Азим", 5*time.Second)
	cache.Set("Возраст", 20, 2*time.Second)

	if val, ok := cache.Get("Имя"); ok {
		fmt.Printf("Имя: %v\n", val)
	}

	if val, ok := cache.Get("Возраст"); ok {
		fmt.Printf("Возраст: %v\n", val)
	}

	cache.Delete("Возраст")
	if _, ok := cache.Get("Возраст"); !ok {
		fmt.Println("Возраст удален")
	}

	time.Sleep(5 * time.Second)
	if _, ok := cache.Get("Имя"); !ok {
		fmt.Println("Имя истекло")
	}
}
