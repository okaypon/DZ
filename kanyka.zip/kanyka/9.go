package main

import "fmt"

type Employee struct {
	ID       int
	Name     string
	Position string
	Salary   float64
}

type Department struct {
	Name      string
	employees []Employee
	nextID    int
}

func (d *Department) AddEmployee(name string, position string, salary float64) {
	employee := Employee{
		ID:       d.nextID,
		Name:     name,
		Position: position,
		Salary:   salary}
	d.employees = append(d.employees, employee)
	d.nextID++
	fmt.Printf("добавлен: %s - %s\n", name, position)
}

func (d *Department) RemoveEmployee(id int) {
	for i, employee := range d.employees {
		if employee.ID == id {
			d.employees = append(d.employees[:i], d.employees[i+1:]...)
			fmt.Printf("удален: %s\n", employee.Name)
			return
		}
	}
}

func (d *Department) GetTotalSalary() float64 {
	total := 0.0
	for _, employee := range d.employees {
		total += employee.Salary
	}
	return total
}

func main() {
	hospital := Department{Name: "Больница"}

	hospital.AddEmployee("Азим", "хирург", 150000)
	hospital.AddEmployee("Амир", "терапевт", 100000)
	fmt.Printf("фонд зарплат: %.0f\n", hospital.GetTotalSalary())
	hospital.RemoveEmployee(0)
	fmt.Printf("фонд зарплат после удаления: %.0f\n", hospital.GetTotalSalary())
}
