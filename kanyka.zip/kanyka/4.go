package main

import "fmt"

type Order struct {
	ID       int
	Customer Customer
	Items    []OrderItem
	Status   string
}

type OrderItem struct {
	ProductID int
	Name      string
	Price     float64
	Quantity  int
}

type Customer struct {
	ID   int
	Name string
}

func (o *Order) AddItem(productID int, name string, price float64, quantity int) {
	item := OrderItem{productID, name, price, quantity}
	o.Items = append(o.Items, item)
}

func (o *Order) RemoveItem(productID int) error {
	for i, item := range o.Items {
		if item.ProductID == productID {
			o.Items = append(o.Items[:i], o.Items[i+1:]...)
			return nil
		}
	}
	return fmt.Errorf("товар не найден")
}

func (o *Order) GetTotal() float64 {
	total := 0.0
	for _, item := range o.Items {
		total += item.Price * float64(item.Quantity)
	}
	return total
}

func (o *Order) UpdateStatus(status string) {
	o.Status = status
}

func main() {
	order := Order{1, Customer{1, "Азим"}, []OrderItem{}, "новый"}

	order.AddItem(1, "калькулятор", 230, 15)
	order.AddItem(2, "мышь компьютерная", 12430, 5)

	fmt.Printf("общая сумма: %.2f\n", order.GetTotal())

	order.UpdateStatus("обработан")
	order.RemoveItem(1)

	fmt.Printf("общая стоимость после удаления товара: %.2f\n", order.GetTotal())
	fmt.Printf("статус: %s\n", order.Status)
}
