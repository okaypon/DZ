package main

import (
  "fmt"
  "errors"
)

type BankAccount struct{
    AccountNumber int
    holderName string
    balance float64
}


func (account * BankAccount) Deposit(popolnenie float64){
  fmt.Println("пополнения")
  if popolnenie > 0 {
    account.balance += popolnenie
  }
}

func (account *BankAccount) Withdraw(spisanie float64) error {
  fmt.Println("списания")
 if spisanie <= 0 {
  return errors.New("отрицательное число вводить запрещено")
 }
 if spisanie > account.balance {
  return errors.New("баланса не достаточно для выполнения операции")
 }
 account.balance -= spisanie
 return nil
}

func (account *BankAccount) GetBalance() float64 {
 return account.balance
}

func (account *BankAccount) PrintBalance() {
 fmt.Printf("ваш счёт составляет: %.2f\n", account.balance)
}

func main(){
  account := BankAccount{
    AccountNumber: 524,
    holderName: "Азим Попуев Маратович",
    balance:    100.0,
  }
  account.Deposit(800.50)
  account.PrintBalance()

  err := account.Withdraw(100.0)
   if err != nil {
    fmt.Println("ошибка:", err)
   } else {
  account.PrintBalance()
 }
   err = account.Withdraw(5222.2)
   if err != nil {
    fmt.Println("ошибка:", err)
   } else {
    account.PrintBalance()
  }
}