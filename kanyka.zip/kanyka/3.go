package main

import (
	"crypto/sha256"
	"fmt"
)

type User struct {
	Username string
	Email    string
	Password string
}

func (u *User) SetPassword(password string) {
	heshirovanie := sha256.Sum256([]byte(password))
	u.Password = fmt.Sprintf("%x", heshirovanie)
}

func (u *User) VerifyPassword(password string) bool {
	heshirovanie := sha256.Sum256([]byte(password))
	hashedPassword := fmt.Sprintf("%x", heshirovanie)
	return u.Password == hashedPassword
}

func main() {
	user := User{
		Username: "Алешка",
		Email:    "aleshka@gmail.com",
	}

	user.SetPassword("haha")

	fmt.Println("проверка правильного пароля:", user.VerifyPassword("haha"))
	fmt.Println("проверка неправильного пароля:", user.VerifyPassword("ok"))
}
