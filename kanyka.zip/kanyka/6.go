package main

import "fmt"

type EventBus struct {
	subscribers map[string][]func(interface{})
}

func (e *EventBus) Subscribe(event string, handler func(interface{})) {
	if e.subscribers == nil {
		e.subscribers = make(map[string][]func(interface{}))
	}
	e.subscribers[event] = append(e.subscribers[event], handler)
}

func (e *EventBus) Publish(event string, data interface{}) {
	for _, handler := range e.subscribers[event] {
		handler(data)
	}
}

func main() {
	var sub EventBus

	sub.Subscribe("подписка", func(data interface{}) {
		fmt.Printf("Подписался на событие: %v\n", data)
	})

	sub.Publish("подписка", "ааа")
}
