package main

import "fmt"

type Book struct {
	ID      int
	Title   string
	Author  string
	IsTaken bool
}

type Library struct {
	books  []Book
	nextID int
}

func (l *Library) AddBook(title string, author string) {
	book := Book{ID: l.nextID, Title: title, Author: author, IsTaken: false}
	l.books = append(l.books, book)
	l.nextID++
}

func (l *Library) FindByAuthor(author string) []Book {
	var result []Book
	for _, book := range l.books {
		if book.Author == author {
			result = append(result, book)
		}
	}
	return result
}

func (l *Library) FindByTitle(title string) []Book {
	var result []Book
	for _, book := range l.books {
		if book.Title == title {
			result = append(result, book)
		}
	}
	return result
}

func (l *Library) TakeBook(id int) bool {
	for i, book := range l.books {
		if book.ID == id && !book.IsTaken {
			l.books[i].IsTaken = true
			return true
		}
	}
	return false
}

func (l *Library) ReturnBook(id int) bool {
	for i, book := range l.books {
		if book.ID == id && book.IsTaken {
			l.books[i].IsTaken = false
			return true
		}
	}
	return false
}

func main() {
	var library Library

	library.AddBook("Война и мир", "Толстой")
	library.AddBook("Мастер и Маргарита", "Булгаков")
	library.AddBook("Мертвые души", "Гоголь")

	fmt.Println("книги Булгакова:", len(library.FindByAuthor("Булгаков")))

	if library.TakeBook(0) {
		fmt.Println("книга выдана")
	}

	if library.ReturnBook(0) {
		fmt.Println("книга возвращена")
	}
}
