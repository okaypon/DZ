package main

import (
	"fmt"
	"math/rand"
	"time"
)

const (
	Golova = 1
	Puzo   = 2
	Nogi   = 3
)

func BodyPart(b int) string {
	switch b {
	case Golova:
		return "голова"
	case Puzo:
		return "живот"
	case Nogi:
		return "ноги"
	default:
		return "живот"
	}
}

type Personaj interface {
	Hit() int
	Block() int
	GetWeapon() *Weapon
	RandomWeapon()
}

type Weapon struct {
	Name   string
	MinDmg int
	MaxDmg int
}

type Player struct {
	Name     string
	HP       int
	Strength int
	hit      int
	block    int
	weapon   *Weapon
}

func (p *Player) GetWeapon() *Weapon {
	return p.weapon
}

func (p *Player) Hit() int {
	return p.hit
}

func (p *Player) Block() int {
	return p.block
}

func (p *Player) RandomWeapon() {
	weapons := []Weapon{
		{"Glock-18", 15, 25},
		{"AK-47", 28, 100},
		{"MAC-10", 28, 69},
		{"AWP", 84, 100},
		{"Scout", 60, 100},
	}
	p.weapon = &weapons[rand.Intn(len(weapons))]
}

func generateRoundStory(round int, p *Player, e *Enemy) string {
	switch round {
	case 1:
		return "ПЕРВЫЙ КОНТАКТ - Бойцы занимают позиции на карте de_dust2..."
	case 3:
		return "ЭКО-РАУНД - Противники экономят, но все равно сходятся в бою..."
	case 5:
		return "ФОРС-БУЙ - Обе команды покупают нормальное оружие за раунд..."
	case 7:
		return "КЛАТЧ-СИТУАЦИЯ - Все зависит от игроков..."
	case 9:
		return "МАТЧ-ПОЙНТ - Следующий раунд может решить исход всей игры..."
	}
	stories := []string{
		"ТЕРРОРИСТЫ ВЫСТАВЛЕНИЯ A - Контр-террористы проверяют углы",
		"ВРЫВ B",
		"СНАЙПЕРСКАЯ ДУЭЛЬ - " + p.weapon.Name + " против " + e.weapon.Name + " на миде",
		"ЗАКЛАДКА БОМБЫ - Террористы движутся к точке A",
		"ОБЕЗВРЕЖИВАНИЕ - Контр-террористы ищут бомбу",
		"ФЛЭШБЭК - Противники ослеплены светошумовыми",
	}

	return stories[rand.Intn(len(stories))]
}

func describeRoundResult(p *Player, e *Enemy, pHit, eHit int, pDamage, eDamage int) {
	if pDamage > 0 {
		fmt.Println(p.Name, "наносит противнику из", p.weapon.Name, "[", pDamage, "Damaga]")
	}

	if eDamage > 0 {
		fmt.Println(e.Name, "наносит противнику из", e.weapon.Name, "[", eDamage, "Damaga]")
	}
}

type Enemy struct {
	Name     string
	HP       int
	Strength int
	hit      int
	block    int
	weapon   *Weapon
}

func (e *Enemy) GetWeapon() *Weapon {
	return e.weapon
}

func (e *Enemy) Hit() int {
	return e.hit
}

func (e *Enemy) Block() int {
	return e.block
}

func PlayerHitBlock(p *Player) {
	var attack, defence int
	fmt.Println("Выберите часть тела для атаки")
	fmt.Println("1-Голова, 2-Живот, 3-Ноги")
	fmt.Scan(&attack)

	if attack < 1 || attack > 3 {
		attack = Puzo
		fmt.Println("Неверный выбор! Установлено значение по умолчанию: живот")
	}
	p.hit = attack

	fmt.Println("Выберите часть тела для защиты")
	fmt.Println("1-Голова, 2-Живот, 3-Ноги")
	fmt.Scan(&defence)

	if defence < 1 || defence > 3 {
		defence = Puzo
		fmt.Println("Неверный выбор! Установлено значение по умолчанию: живот")
	}
	p.block = defence
}

func EnemyHitBlock(e *Enemy) {
	e.hit = rand.Intn(3) + 1
	e.block = rand.Intn(3) + 1
}

func (e *Enemy) RandomWeapon() {
	weapons := []Weapon{
		{"USP-S", 15, 25},
		{"M4A4", 28, 89},
		{"M4A1-S", 28, 89},
		{"FAMAS", 25, 84},
		{"AWP", 84, 100},
	}
	e.weapon = &weapons[rand.Intn(len(weapons))]
}

func Round(p *Player, e *Enemy) {
	if p.Hit() != e.Block() {
		damage := calculateDamage(p.Strength, p.weapon)
		e.HP -= damage
		fmt.Println(p.Name, "наносит", damage, "урона", e.Name)
	} else {
		fmt.Println(e.Name, "блокирует удар", p.Name)
	}

	if e.HP > 0 && e.Hit() != p.Block() {
		damage := calculateDamage(e.Strength, e.weapon)
		p.HP -= damage
		fmt.Println(e.Name, "наносит", damage, "урона", p.Name)
	} else if e.HP > 0 {
		fmt.Println(p.Name, "блокирует удар", e.Name)
	}
}

func calculateDamage(strength int, weapon *Weapon) int {
	baseDamage := rand.Intn(weapon.MaxDmg-weapon.MinDmg+1) + weapon.MinDmg
	return baseDamage
}

func Status(p *Player, e *Enemy) {
	fmt.Println("HP:", p.Name, p.HP, e.Name, e.HP)
}

func Winner(p *Player, e *Enemy) {
	if p.HP > 0 {
		fmt.Println("Победитель:", p.Name)
		fmt.Println("Проигравший:", e.Name)
	} else {
		fmt.Println("Победитель:", e.Name)
		fmt.Println("Проигравший:", p.Name)
	}
}

func fight(p *Player, e *Enemy) {
	rand.Seed(time.Now().UnixNano())
	round := 1
	fmt.Printf("\nИГРА 1х1 НАЧАЛАСЬ:\n")
	fmt.Println(p.Name, "vs", e.Name)

	p.RandomWeapon()
	e.RandomWeapon()

	for p.HP > 0 && e.HP > 0 {
		fmt.Println("Раунд - ", round)

		if story := generateRoundStory(round, p, e); story != "" {
			fmt.Println(story)
		}

		if rand.Float32() < 0.3 {
			p.RandomWeapon()
			fmt.Println(p.Name, "с оружием: ", p.weapon.Name, "(", p.weapon.MinDmg, "-", p.weapon.MaxDmg, "урона)")
		}

		PlayerHitBlock(p)
		EnemyHitBlock(e)

		fmt.Println(p.Name, "атакует", BodyPart(p.Hit()), "и защищает", BodyPart(p.Block()))
		fmt.Println(e.Name, "атакует", BodyPart(e.Hit()), "и защищает", BodyPart(e.Block()))

		pHPBefore := p.HP
		eHPBefore := e.HP

		Round(p, e)

		pDamage := pHPBefore - p.HP
		eDamage := eHPBefore - e.HP

		if eDamage > 0 || pDamage > 0 {
			describeRoundResult(p, e, p.Hit(), e.Hit(), pDamage, eDamage)
		}

		fmt.Println("\nСТАТУС ПОСЛЕ РАУНДА:")
		fmt.Print("\n", p.Name, ":", p.HP, "HP")

		fmt.Print("\n", e.Name, ":", e.HP, "HP\n")

		round++
		time.Sleep(2 * time.Second)
	}

	fmt.Println("\nИГРА ОКОНЧЕНА:")
	Winner(p, e)

	fmt.Println("\nСТАТИСТИКА БОЯ:")
	fmt.Println("Количество раундов:", round-1)
	if p.HP > 0 {
		fmt.Println(p.Name, "победил с", p.HP, "HP")
		fmt.Println("Оружие победителя:", p.weapon.Name)
	} else {
		fmt.Println(e.Name, "победил с", e.HP, "HP")
		fmt.Println("Оружие победителя:", e.weapon.Name)
	}
}

func main() {
	player := &Player{
		Name:     "Ама",
		HP:       100,
		Strength: 0,
	}

	enemy := &Enemy{
		Name:     "Дамир",
		HP:       100,
		Strength: 0,
	}

	fight(player, enemy)
}
