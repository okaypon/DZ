package main

import (
	"fmt"
	"math"
)

type Shape interface {
	Area() float64
	Perimeter() float64
}

type Rectangle struct {
	shirina float64
	visota  float64
}

func (r Rectangle) Area() float64 {
	return r.shirina * r.visota
}

func (r Rectangle) Perimeter() float64 {
	return 2 * (r.shirina + r.visota)
}

type Circle struct {
	Radius float64
}

func (c Circle) Area() float64 {
	return math.Pi * c.Radius * c.Radius
}

func (c Circle) Perimeter() float64 {
	return 2 * math.Pi * c.Radius
}

type Triangle struct {
	A float64
	B float64
	C float64
}

func (t Triangle) Area() float64 {
	p := t.Perimeter() / 2
	return math.Sqrt(p * (p - t.A) * (p - t.B) * (p - t.C))
}

func (t Triangle) Perimeter() float64 {
	return t.A + t.B + t.C
}

func main() {
	rectangle := Rectangle{shirina: 10, visota: 5}
	fmt.Printf("Прямоугольник (10 x 5):\n")
	fmt.Printf("  Площадь: %.2f\n", rectangle.Area())
	fmt.Printf("  Периметр: %.2f\n", rectangle.Perimeter())

	circle := Circle{Radius: 7}
	fmt.Printf("Круг (радиус = 7):\n")
	fmt.Printf("  Площадь: %.2f\n", circle.Area())
	fmt.Printf("  Периметр: %.2f\n", circle.Perimeter())

	triangle := Triangle{A: 3, B: 4, C: 5}
	fmt.Printf("Треугольник (стороны 3 - 4 - 5):\n")
	fmt.Printf("  Площадь: %.2f\n", triangle.Area())
	fmt.Printf("  Периметр: %.2f\n", triangle.Perimeter())
}
