package main

import (
	"errors"
	"fmt"
)

type Validator interface {
	Validate(value string) error
}

type Field struct {
	Name       string
	Value      string
	Validators []Validator
}

type RequiredValidator struct{}

func (r RequiredValidator) Validate(value string) error {
	if value == "" {
		return errors.New("поле обязательно для заполнения")
	}
	return nil
}

type LengthValidator struct {
	Min int
	Max int
}

func (l LengthValidator) Validate(value string) error {
	length := len(value)
	if length < l.Min {
		return errors.New("слишком короткое значение")
	}
	if l.Max > 0 && length > l.Max {
		return errors.New("слишком длинное значение")
	}
	return nil
}

type EmailValidator struct{}

func (e EmailValidator) Validate(value string) error {
	if value == "" {
		return nil
	}
	if len(value) < 3 || !contains(value, "@") {
		return errors.New("неверный формат email")
	}
	return nil
}

func contains(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

func main() {
	field := Field{
		Name:  "email",
		Value: "lololo-gmail.com",
		Validators: []Validator{
			RequiredValidator{},
			EmailValidator{},
		},
	}

	for _, validator := range field.Validators {
		err := validator.Validate(field.Value)
		if err != nil {
			fmt.Println("ошибка:", err)
		}
	}
}
